import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { FiSearch, FiDownload, FiChevronDown, FiChevronUp, FiEdit, FiClipboard } from 'react-icons/fi';
import api from '../../api/api.js';
import { Badge, Pagination, PageLoader, EmptyState, Modal } from '../../components/ui/index.jsx';

const STATUS_OPTIONS = ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Completed', 'Cancelled'];
const PAYMENT_OPTIONS = ['Pending', 'Paid', 'Refunded'];

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [meta, setMeta] = useState({ page: 1, totalPages: 1 });
  const [filters, setFilters] = useState({ search: '', orderStatus: '', paymentStatus: '', page: 1 });
  const [expandedId, setExpandedId] = useState(null);
  const [editOrder, setEditOrder] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { document.title = 'Orders – Admin'; }, []);

  const fetchOrders = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/orders', { params }).then((r) => {
      setOrders(r.data.data);
      setMeta(r.data.meta);
    }).finally(() => setLoading(false));
  };

  useEffect(() => { fetchOrders(); }, [filters]);

  const handleUpdate = async () => {
    setSaving(true);
    try {
      await api.put(`/orders/${editOrder._id}/status`, editForm);
      toast.success('Order updated');
      setEditOrder(null);
      fetchOrders();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally { setSaving(false); }
  };

  const downloadInvoice = async (orderId, orderNumber) => {
    const res = await api.get(`/orders/${orderId}/invoice`, { responseType: 'blob' });
    const url = URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a'); a.href = url; a.download = `invoice-${orderNumber}.pdf`; a.click();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl font-bold text-gray-900">Orders</h1>
      </div>

      {/* Filters */}
      <div className="admin-card mb-6 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input placeholder="Search by order #, name, phone..." value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value, page: 1 })}
            className="input-field pl-10 text-sm py-2.5" />
        </div>
        <select value={filters.orderStatus} onChange={(e) => setFilters({ ...filters, orderStatus: e.target.value, page: 1 })}
          className="input-field text-sm py-2.5 w-auto">
          <option value="">All Statuses</option>
          {STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select value={filters.paymentStatus} onChange={(e) => setFilters({ ...filters, paymentStatus: e.target.value, page: 1 })}
          className="input-field text-sm py-2.5 w-auto">
          <option value="">All Payments</option>
          {PAYMENT_OPTIONS.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {loading ? <PageLoader /> : orders.length === 0 ? (
        <EmptyState icon={<FiClipboard size={56} />} title="No orders found" message="Orders will appear here once customers start placing them." />
      ) : (
        <>
          <div className="space-y-3">
            {orders.map((order) => (
              <motion.div key={order._id} layout className="admin-card overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="font-bold text-sm text-gray-800">{order.orderNumber}</span>
                      <Badge status={order.orderStatus} />
                      <Badge status={order.paymentStatus} type="payment" />
                      {order.source === 'offline' && <span className="badge badge-blue">Offline</span>}
                    </div>
                    <p className="text-sm text-gray-600">{order.customerName} · {order.customerPhone}</p>
                    <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleString('en-IN')} · ₹{order.totalAmount}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => { setEditOrder(order); setEditForm({ orderStatus: order.orderStatus, paymentStatus: order.paymentStatus, adminNotes: order.adminNotes || '' }); }}
                      className="p-2 text-gray-400 hover:text-brand-500 hover:bg-brand-50 rounded-lg transition-colors">
                      <FiEdit size={16} />
                    </button>
                    <button onClick={() => downloadInvoice(order._id, order.orderNumber)}
                      className="p-2 text-gray-400 hover:text-brand-500 hover:bg-brand-50 rounded-lg transition-colors">
                      <FiDownload size={16} />
                    </button>
                    <button onClick={() => setExpandedId(expandedId === order._id ? null : order._id)}
                      className="p-2 text-gray-400 hover:text-gray-600 rounded-lg transition-colors">
                      {expandedId === order._id ? <FiChevronUp size={16} /> : <FiChevronDown size={16} />}
                    </button>
                  </div>
                </div>

                {expandedId === order._id && (
                  <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }}
                    className="border-t border-gray-100 pt-4 mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Order Items</p>
                      <div className="space-y-1">
                        {order.items.map((item, i) => (
                          <div key={i} className="flex justify-between text-sm">
                            <span className="text-gray-700">{item.name} ×{item.quantity}</span>
                            <span className="font-medium">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                        <div className="border-t pt-1 flex justify-between font-bold text-sm">
                          <span>Total</span><span className="text-brand-600">₹{order.totalAmount}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-sm space-y-1.5">
                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Customer Details</p>
                      <p><span className="text-gray-500">Phone:</span> {order.customerPhone}</p>
                      <p><span className="text-gray-500">Address:</span> {order.customerAddress}</p>
                      {order.customerNotes && <p><span className="text-gray-500">Notes:</span> {order.customerNotes}</p>}
                      {order.paymentScreenshot && (
                        <a href={order.paymentScreenshot} target="_blank" rel="noopener noreferrer"
                          className="text-brand-500 hover:underline text-xs">View Payment Screenshot →</a>
                      )}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
          <Pagination currentPage={meta.page} totalPages={meta.totalPages}
            onPageChange={(p) => setFilters({ ...filters, page: p })} />
        </>
      )}

      {/* Edit Modal */}
      <Modal isOpen={!!editOrder} onClose={() => setEditOrder(null)} title={`Update Order: ${editOrder?.orderNumber}`}>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Order Status</label>
            <select value={editForm.orderStatus} onChange={(e) => setEditForm({ ...editForm, orderStatus: e.target.value })}
              className="input-field">
              {STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Payment Status</label>
            <select value={editForm.paymentStatus} onChange={(e) => setEditForm({ ...editForm, paymentStatus: e.target.value })}
              className="input-field">
              {PAYMENT_OPTIONS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Admin Notes</label>
            <textarea value={editForm.adminNotes} onChange={(e) => setEditForm({ ...editForm, adminNotes: e.target.value })}
              className="input-field resize-none" rows={3} />
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={() => setEditOrder(null)} className="btn-outline flex-1">Cancel</button>
            <button onClick={handleUpdate} disabled={saving} className="btn-primary flex-1">
              {saving ? 'Saving...' : 'Update Order'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
